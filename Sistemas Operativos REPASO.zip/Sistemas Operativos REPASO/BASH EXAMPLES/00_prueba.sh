#! /bin/bash
# ******************************************************************
# 1 Capicúas
# Se tiene un archivo con números enteros de 3 dígitos, se desea generar otro archivo con los
# capicúas de cada uno de los números
# {} [] /\ ^$
# ******************************************************************

#Creeo archivo input
echo "Ejercicio PRUEBA."

DIR_PROC="./DATAS/FACTURAS/"
UNO=1
DOS=2

TRES=$((UNO * DOS))

echo $TRES

echo "Fin ejercicio PRUEBA."